const readline = require('readline');
const rl = readline.createInterface({ input: process.stdin, terminal: false });

function send(id, result) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result }) + '\n');
}

rl.on('line', (line) => {
  if (!line.trim()) return;
  let msg;
  try {
    msg = JSON.parse(line);
  } catch (e) {
    return;
  }

  if (msg.method === 'initialize') {
    send(msg.id, {
      protocolVersion: '2024-11-05',
      serverInfo: { name: 'word-counter', version: '1.0.0' },
      capabilities: { tools: {} }
    });
  }

  if (msg.method === 'tools/list') {
    send(msg.id, {
      tools: [{
        name: 'count_words',
        description: 'Counts the number of words in the given text',
        inputSchema: {
          type: 'object',
          properties: { text: { type: 'string' } },
          required: ['text']
        }
      }]
    });
  }

  if (msg.method === 'tools/call' && msg.params?.name === 'count_words') {
    const text = msg.params?.arguments?.text || '';
    const count = text.trim().split(/\s+/).filter(Boolean).length;
    send(msg.id, {
      content: [{ type: 'text', text: `Word count: ${count}` }]
    });
  }
});
