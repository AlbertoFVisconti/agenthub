# my-cool-tool

An AgentHub tool.

## Testing Locally
Run `npx @agenthub/tool-cli validate` to validate your manifest.
Run `npx @agenthub/tool-cli test` to test your tool locally using Docker.

## Publishing
Run `npx @agenthub/tool-cli package` to bundle your tool into a zip file.
Upload the resulting `<name>-<version>.zip` directly through the AgentHub Marketplace Dashboard.
