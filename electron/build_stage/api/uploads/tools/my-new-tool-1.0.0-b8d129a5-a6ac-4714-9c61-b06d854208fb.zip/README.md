# my-new-tool

An AgentHub tool.

## Testing Locally
Run `npx agenthub-tool validate` to validate your manifest.
Run `npx agenthub-tool test` to test your tool locally using Docker.

## Publishing
Zip the contents of this folder (not the folder itself) and upload it via the AgentHub Marketplace Dashboard.
