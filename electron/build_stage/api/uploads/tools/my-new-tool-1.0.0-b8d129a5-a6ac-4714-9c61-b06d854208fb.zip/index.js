import { defineTool } from '@agenthub/tool-sdk'

defineTool({
  name: 'my-new-tool',
  description: 'Counts words in text',
  inputSchema: {
    type: 'object',
    properties: { text: { type: 'string' } },
    required: ['text']
  },
  handler: async ({ text }) => {
    const count = text.trim().split(/\s+/).filter(Boolean).length
    return `Word count: ${count}`
  }
})
